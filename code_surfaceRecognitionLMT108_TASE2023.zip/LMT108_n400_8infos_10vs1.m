%{

Description: generates result 10 vs. 1 classification setting

Author: Behnam Khojasteh (khojasteh@is.mpg.de)
Last Modification Date: 31.01.2023

This script is part of the publication:
@article{khojasteh2023multimodal,
  title={Multimodal Multi-User Surface Recognition with the Kernel Two-Sample Test},
  author={Khojasteh, Behnam and Solowjow, Friedrich and Trimpe, Sebastian and Kuchenbecker, Katherine J},
  journal={IEEE Transactions on Automation Science and Engineering (T-ASE)},
  year={2023}
}

%}

clear all; clc; 

rng('default'); % Reproducibility: Fixed indices for data extraction
rng(1);
constantStream = parallel.pool.Constant(RandStream('Threefry'));

addpath('supportFunctions');
addpath('DataLMT108/Library');
addpath('DataLMT108/TestingSet');

description = 'LMT108_10vs1_8infos_Gauss';

crossUserTrick = 'MeanShift'; % 'MeanShift';

% =========== eight information sources
% ca1+ca2: camera images without and with flash
% mi1+mi2: sound from tapping and dragging
% ac: accelerations during dragging
% fr: frictional forces
% ir: infra-red surface reflectivity
% me: metal detection

%% Trial Names

testSetting = load("DataLMT108/TestingSet/surfaceList_LMT108test.mat");
trainSetting = load("DataLMT108/Library/surfaceList_LMT108train.mat");

surfaceTrialList_Testing = testSetting.trialList_Testing;
surfaceTrialList_Training = trainSetting.trialList_Training;

numTrials_Test = size(surfaceTrialList_Testing,1);
numTrials_Train = size(surfaceTrialList_Training,1);

trialsPerSurfaceTesting = 10; % users
numSurfaces = numTrials_Test / trialsPerSurfaceTesting;
trialsPerSurface = 20; % 10+10 (10 users + 1 expert)

numTrials_Train = 2*size(surfaceTrialList_Training,1) - numSurfaces; % librarySize

%% Data Selection + Testing parameters

alpha = 0.05;
params.sig = -1; % heuristic kernel size computation
params.bootForce = 0; 
params.sigBinary = -1; % heuristic kernel size computation for metal information source

n = 400; % sample size; m = n
R = 10;  % number of repetitions of the kernel two-sample test

% %% Time Series
tMeasDuration_DAQ = 48E3; 
t0Range_idx = 0.0115*tMeasDuration_DAQ; 
T = floor((tMeasDuration_DAQ-t0Range_idx)/n);

% %% Images
a = 480;
b = 320;
n_a = 25;
n_b = 16;
a0_range = 55; 
b0_range = 32; 
d_a = floor((a-a0_range)/n_a);
d_b = floor((b-b0_range)/n_b);

%% Frequency Ranges

specInfo.fRange_ac = [0 1E3];
specInfo.fRange_mi = [0 7.5E3];
specInfo.fs_ac = 10E3;
specInfo.fs_mi = 44.1E3;

trialZero = load(sprintf('DataLMT108/TestingSet/%s',surfaceTrialList_Testing(1)));
signal_mi1 = trialZero.soundTap_time;
signal_mi2 = trialZero.soundDrag_time;
signal_ac = trialZero.accelDrag_time(:,3);

[Y_mi1, f_mi1] = powerSpectrum(signal_mi1,specInfo.fs_mi);
[Y_mi2, f_mi2] = powerSpectrum(signal_mi2,specInfo.fs_mi);
[Y_ac, f_ac] = powerSpectrum(signal_ac,specInfo.fs_ac);

[fMin_mi1 fMax_mi1] = getFreqIdx(f_mi1,specInfo.fRange_mi);
[fMin_mi2 fMax_mi2] = getFreqIdx(f_mi2,specInfo.fRange_mi);
[fMin_ac fMax_ac] = getFreqIdx(f_ac,specInfo.fRange_ac);

%% Definition Training and Testing Split

names_allSurfaceTrials = sort([surfaceTrialList_Testing;surfaceTrialList_Training]); % create larger training set

trainIndicesUsers = zeros(trialsPerSurfaceTesting,numSurfaces*(trialsPerSurface-1));
parfor i=1:trialsPerSurfaceTesting
    indices = [i:trialsPerSurface:numSurfaces*trialsPerSurface];
    trainIndicesUsers(i,:) = setdiff([1:numSurfaces*trialsPerSurface],indices);
end
idxTrain = repmat(trainIndicesUsers,numSurfaces,1);

idxTest = [1:numSurfaces*trialsPerSurfaceTesting];

%% Similarity testing

MMDmatrix_ca1 = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ca2 = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_mi1 = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_mi2 = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ac = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_fr = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ir = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_me = zeros(numTrials_Test,numTrials_Train,R);


parfor i = 1:numTrials_Test
    
    stream = constantStream.Value;        % stream from constant
    stream.Substream = i;
    
    nameZ = surfaceTrialList_Testing(idxTest(i));
    datasetZ = load(sprintf('DataLMT108/TestingSet/%s.mat',nameZ));
    
    surfaceSetZ_ca1 = datasetZ.imageNoFlash_RGB;
    signalSetZ_ca1 = rgb2hsv(surfaceSetZ_ca1); 
    
    surfaceSetZ_ca2 = datasetZ.imageFlash_RGB;
    signalSetZ_ca2 = rgb2hsv(surfaceSetZ_ca2); 
    
    surfaceSetZ_mi1 = datasetZ.soundTap_time;
    [specAmplitudeZ_mi1, ~] = powerSpectrum(surfaceSetZ_mi1, specInfo.fs_mi); % FFT
    signalSetZ_mi1 = specAmplitudeZ_mi1(fMin_mi1:fMax_mi1,1);
    
    surfaceSetZ_mi2 = datasetZ.soundDrag_time;
    [specAmplitudeZ_mi2, ~] = powerSpectrum(surfaceSetZ_mi2, specInfo.fs_mi);  % FFT
    signalSetZ_mi2 = specAmplitudeZ_mi2(fMin_mi2:fMax_mi2,1);
    
    surfaceSetZ_ac = datasetZ.accelDrag_time;
    [specAmplitudeZ_ac, ~] = powerSpectrum(surfaceSetZ_ac, specInfo.fs_ac);     % FFT
    signalSetZ_ac = specAmplitudeZ_ac(fMin_ac:fMax_ac,1:3);
    
    surfaceSetZ_fr = datasetZ.forceDrag_time(:,1:2);
    signalSetZ_fr = surfaceSetZ_fr;
    
    surfaceSetZ_ir = datasetZ.reflectDrag_time;
    signalSetZ_ir = surfaceSetZ_ir;
    
    surfaceSetZ_me = datasetZ.metalDrag_time;
    signalSetZ_me = surfaceSetZ_me;
    
    for j = 1:numTrials_Train
        
        nameY = names_allSurfaceTrials(idxTrain(i,j));
        FileList = dir(fullfile('DataLMT108', '**', sprintf('%s.mat',nameY)));
        datasetY = load(sprintf('%s/%s',FileList.folder,FileList.name));
        
        surfaceSetY_ca1 = datasetY.imageNoFlash_RGB;
        signalSetY_ca1 = rgb2hsv(surfaceSetY_ca1); 
        
        surfaceSetY_ca2 = datasetY.imageFlash_RGB;
        signalSetY_ca2 = rgb2hsv(surfaceSetY_ca2); 
        
        surfaceSetY_mi1 = datasetY.soundTap_time;
        [specAmplitudeY_mi1, ~] = powerSpectrum(surfaceSetY_mi1, specInfo.fs_mi); % FFT
        signalSetY_mi1 = specAmplitudeY_mi1(fMin_mi1:fMax_mi1,1);
        
        surfaceSetY_mi2 = datasetY.soundDrag_time;
        [specAmplitudeY_mi2, ~] = powerSpectrum(surfaceSetY_mi2, specInfo.fs_mi); % FFT
        signalSetY_mi2 = specAmplitudeY_mi2(fMin_mi2:fMax_mi2,1);
        
        surfaceSetY_ac = datasetY.accelDrag_time;
        [specAmplitudeY_ac, ~] = powerSpectrum(surfaceSetY_ac, specInfo.fs_ac);   % FFT
        signalSetY_ac = specAmplitudeY_ac(fMin_ac:fMax_ac,1:3);
        
        surfaceSetY_fr = datasetY.forceDrag_time;
        signalSetY_fr = surfaceSetY_fr;
        
        surfaceSetY_ir = datasetY.reflectDrag_time;
        signalSetY_ir = surfaceSetY_ir;
        
        surfaceSetY_me = datasetY.metalDrag_time;
        signalSetY_me = surfaceSetY_me;
        
        for k = 1:R
            
            %% Equidistant sampling for images and time series
            
            a0 = randi(stream,a0_range,1);
            b0 = randi(stream,b0_range,1);
            idx_a = [a0:d_a:a0-1+d_a*n_a];
            idx_b = [b0:d_b:b0-1+d_b*n_b];
            
            Z_ca1 = signalSetZ_ca1(idx_a,idx_b,1:3);
            Z_ca1 = reshape(Z_ca1,[],3);
            Y_ca1 = signalSetY_ca1(idx_a,idx_b,1:3);
            Y_ca1 = reshape(Y_ca1,[],3);
            
            Z_ca2 = signalSetZ_ca2(idx_a,idx_b,1:3);
            Z_ca2 = reshape(Z_ca2,[],3);
            Y_ca2 = signalSetY_ca2(idx_a,idx_b,1:3);
            Y_ca2 = reshape(Y_ca2,[],3);
            
            t0 = randi(stream,t0Range_idx,1);
            idx_time = [t0:T:t0-1+T*n];
            Z_fr = signalSetZ_fr(idx_time,:);
            Y_fr = signalSetY_fr(idx_time,:);
            Z_ir = signalSetZ_ir(idx_time,:);
            Y_ir = signalSetY_ir(idx_time,:);
            Z_me = signalSetZ_me(idx_time,:);
            Y_me = signalSetY_me(idx_time,:);
            
            %% Random sampling in spectral domain
            
            idx_mi1 = randperm(stream,size(signalSetZ_mi1,1),n);
            Z_mi1 = signalSetZ_mi1(idx_mi1,:); 
            Y_mi1 = signalSetY_mi1(idx_mi1,:);
            
            idx_mi2 = randperm(stream,size(signalSetZ_mi2,1),n);
            Z_mi2 = signalSetZ_mi2(idx_mi2,:); 
            Y_mi2 = signalSetY_mi2(idx_mi2,:);
            
            idx_ac = randperm(stream,size(signalSetZ_ac,1),n);
            Z_ac = signalSetZ_ac(idx_ac,:); 
            Y_ac = signalSetY_ac(idx_ac,:);
            
            %% Align mean of distributions
            
            if(crossUserTrick == 'NoMeanShift')
                Z_mi1 = alginMean(Y_mi1,Z_mi1);
                Z_mi2 = alginMean(Y_mi2,Z_mi2);
                Z_ac = alginMean(Y_ac,Z_ac);
                Z_fr = alginMean(Y_fr,Z_fr);
                Z_ir = alginMean(Y_ir,Z_ir);
            end
            
            %% Kernel Two-Sample testing
            
            [MMD_ca1,~] = mmdTestBoot(Z_ca1,Y_ca1,alpha, params);
            [MMD_ca2,~] = mmdTestBoot(Z_ca2,Y_ca2,alpha, params);
            [MMD_mi1,~] = mmdTestBoot(Z_mi1,Y_mi1,alpha, params);
            [MMD_mi2,~] = mmdTestBoot(Z_mi2,Y_mi2,alpha, params);
            [MMD_ac,~] = mmdTestBoot(Z_ac,Y_ac,alpha, params);
            [MMD_fr,~] = mmdTestBoot(Z_fr,Y_fr,alpha, params);
            [MMD_ir,~] = mmdTestBoot(Z_ir,Y_ir,alpha, params);
            [MMD_me,~] = mmdTestBoot_metal(Z_me,Y_me,alpha, params); % modified original script as described in manuscript to avoid sigma=NaN            
            
            MMDmatrix_ca1(i,j,k) = MMD_ca1;
            MMDmatrix_ca2(i,j,k) = MMD_ca2;
            MMDmatrix_mi1(i,j,k) = MMD_mi1;
            MMDmatrix_mi2(i,j,k) = MMD_mi2;
            MMDmatrix_ac(i,j,k) = MMD_ac;
            MMDmatrix_fr(i,j,k) = MMD_fr;
            MMDmatrix_ir(i,j,k) = MMD_ir;
            MMDmatrix_me(i,j,k) = MMD_me;
            
        end
    end
end

dataname = sprintf('Results/%s_%s_%dtests_n%d_R%d',description,crossUserTrick,numTrials_Test,n,R);

save(dataname,'numTrials_Test','numTrials_Train','testSetting','trainSetting','R','n','specInfo',...
    'MMDmatrix_ca1','MMDmatrix_ca2','MMDmatrix_mi1','MMDmatrix_mi2','MMDmatrix_ac','MMDmatrix_fr','MMDmatrix_ir','MMDmatrix_me',...
    'surfaceTrialList_Testing','names_allSurfaceTrials','idxTrain','idxTest','-v7.3');

