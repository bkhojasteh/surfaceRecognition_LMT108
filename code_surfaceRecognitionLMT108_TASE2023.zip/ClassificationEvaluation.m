%{

Description: evaluates classification performance for various conditions

Author: Behnam Khojasteh (khojasteh@is.mpg.de)
Last Modification Date: 31.01.2023

This script is part of the publication:
@article{khojasteh2023multimodal,
  title={Multimodal Multi-User Surface Recognition with the Kernel Two-Sample Test},
  author={Khojasteh, Behnam and Solowjow, Friedrich and Trimpe, Sebastian and Kuchenbecker, Katherine J},
  journal={IEEE Transactions on Automation Science and Engineering (T-ASE)},
  year={2023}
}

%}

% ===== Classifiction Performance LMT108
clear all; clc; % close all;

addpath('supportFunctions')
addpath('Results')

% Following sections can be executed independently

%% Main Result: 1 expert vs. 10 users 

mainResult = load('Results\mainResult_LMT108_1vs10_8infos_Gauss_5MeanShifts_1080tests_n400_R10'); 

kNeighbors = 1;  
w = ones(8,1); 

MMDmean_ca1 = mean(mainResult.MMDmatrix_ca1,3);
MMDmean_ca2 = mean(mainResult.MMDmatrix_ca2,3);
MMDmean_mi1 = mean(mainResult.MMDmatrix_mi1,3);
MMDmean_mi2 = mean(mainResult.MMDmatrix_mi2,3);
MMDmean_ac = mean(mainResult.MMDmatrix_ac,3);
MMDmean_fr = mean(mainResult.MMDmatrix_fr,3);
MMDmean_ir = mean(mainResult.MMDmatrix_ir,3);
MMDmean_me = mean(mainResult.MMDmatrix_me,3);
MMDmean_me = MMDmean_me + ones(size(MMDmean_me));  % to avoid information loss with geometric means

DS = zeros(size(MMDmean_me)); % discrepancy score
DS = (MMDmean_ca1.^(w(1))).*(MMDmean_ca2.^(w(2))).*(MMDmean_mi1.^(w(3))).*(MMDmean_mi2.^(w(4))).*...
    (MMDmean_ac.^(w(5))).*(MMDmean_fr.^(w(6))).*(MMDmean_ir.^(w(7))).*(MMDmean_me.^(w(8)));

evaluateClassificationLMT108("1vs10",DS,w,kNeighbors);

%% 10 vs. 1 setting

% results10vs1 = load('Results\LMT108_10vs1_8infos_Gauss_NoMeanShift_1080tests_n400_R10'); % no mean shift 
results10vs1 = load('Results\LMT108_10vs1_8infos_Gauss_MeanShift_1080tests_n400_R10'); % mean shift for same 5 time-series information sources

w = ones(8,1); 
kNeighbors = 1;  

MMDmean_ca1 = mean(results10vs1.MMDmatrix_ca1,3);
MMDmean_ca2 = mean(results10vs1.MMDmatrix_ca2,3);
MMDmean_mi1 = mean(results10vs1.MMDmatrix_mi1,3);
MMDmean_mi2 = mean(results10vs1.MMDmatrix_mi2,3);
MMDmean_ac = mean(results10vs1.MMDmatrix_ac,3);
MMDmean_fr = mean(results10vs1.MMDmatrix_fr,3);
MMDmean_ir = mean(results10vs1.MMDmatrix_ir,3);
MMDmean_me = mean(results10vs1.MMDmatrix_me,3);
MMDmean_me = MMDmean_me + ones(size(MMDmean_me));  % to avoid information loss with geometric means

DS_10vs1 = zeros(size(MMDmean_me)); % discrepancy score
DS_10vs1 = (MMDmean_ca1.^(w(1))).*(MMDmean_ca2.^(w(2))).*(MMDmean_mi1.^(w(3))).*(MMDmean_mi2.^(w(4))).*...
    (MMDmean_ac.^(w(5))).*(MMDmean_fr.^(w(6))).*(MMDmean_ir.^(w(7))).*(MMDmean_me.^(w(8)));

evaluateClassificationLMT108("10vs1",DS_10vs1,w,kNeighbors);

%% Ablation Studies: 1 expert vs. 10 users

AB_1vs10 = load('Results\LMT108_Expert_vs_Users_8infos_AblationStudies_1080tests_n400_R10'); 

w = ones(8,1); 
kNeighbors = 1;  

condition = 'HSV';

switch condition  
    
    case 'HSV'        
        MMDmean_ca1 = mean(AB_1vs10.MMD.ca1_RGB_noShift,3);
        MMDmean_ca2 = mean(AB_1vs10.MMD.ca2_RGB_noShift,3);
        MMDmean_mi1 = mean(AB_1vs10.MMD.mi1_Spec_Shift,3);
        MMDmean_mi2 = mean(AB_1vs10.MMD.mi2_Spec_Shift,3);
        MMDmean_ac = mean(AB_1vs10.MMD.ac_Spec_Shift,3);
        MMDmean_fr = mean(AB_1vs10.MMD.fr_Temp_Shift,3);
        MMDmean_ir = mean(AB_1vs10.MMD.ir_Temp_Shift,3);
        MMDmean_me = mean(AB_1vs10.MMD.me_Temp_noShift,3);
        MMDmean_me = MMDmean_me + ones(size(MMDmean_me));  % to avoid information loss with geometric means
        DS_AB_1vs10 = zeros(size(MMDmean_me)); % discrepancy score        
        DS_AB_1vs10 = MMDmean_ca1.*MMDmean_ca2.*MMDmean_mi1.*MMDmean_mi2.*MMDmean_ac.*MMDmean_fr.*MMDmean_ir.*MMDmean_me;        
        
    case 'DFT'        
        MMDmean_ca1 = mean(AB_1vs10.MMD.ca1_HSV_noShift,3);
        MMDmean_ca2 = mean(AB_1vs10.MMD.ca2_HSV_noShift,3);
        MMDmean_mi1 = mean(AB_1vs10.MMD.mi1_Temp_Shift,3);
        MMDmean_mi2 = mean(AB_1vs10.MMD.mi2_Temp_Shift,3);
        MMDmean_ac = mean(AB_1vs10.MMD.ac_Temp_Shift,3);
        MMDmean_fr = mean(AB_1vs10.MMD.fr_Temp_Shift,3);
        MMDmean_ir = mean(AB_1vs10.MMD.ir_Temp_Shift,3);
        MMDmean_me = mean(AB_1vs10.MMD.me_Temp_noShift,3);
        MMDmean_me = MMDmean_me + ones(size(MMDmean_me));  % to avoid information loss with geometric means
        DS_AB_1vs10 = zeros(size(MMDmean_me)); % discrepancy score        
        DS_AB_1vs10 = MMDmean_ca1.*MMDmean_ca2.*MMDmean_mi1.*MMDmean_mi2.*MMDmean_ac.*MMDmean_fr.*MMDmean_ir.*MMDmean_me;      
                
    case 'CrossUserTrick'        
        MMDmean_ca1 = mean(AB_1vs10.MMD.ca1_HSV_noShift,3);
        MMDmean_ca2 = mean(AB_1vs10.MMD.ca2_HSV_noShift,3);
        MMDmean_mi1 = mean(AB_1vs10.MMD.mi1_Spec_noShift,3);
        MMDmean_mi2 = mean(AB_1vs10.MMD.mi2_Spec_noShift,3);
        MMDmean_ac = mean(AB_1vs10.MMD.ac_Spec_noShift,3);
        MMDmean_fr = mean(AB_1vs10.MMD.fr_Temp_noShift,3);
        MMDmean_ir = mean(AB_1vs10.MMD.ir_Temp_noShift,3);
        MMDmean_me = mean(AB_1vs10.MMD.me_Temp_noShift,3);
        MMDmean_me = MMDmean_me + ones(size(MMDmean_me));  % to avoid information loss with geometric means
        DS_AB_1vs10 = zeros(size(MMDmean_me)); % discrepancy score        
        DS_AB_1vs10 = MMDmean_ca1.*MMDmean_ca2.*MMDmean_mi1.*MMDmean_mi2.*MMDmean_ac.*MMDmean_fr.*MMDmean_ir.*MMDmean_me;     
        
    case 'TempPlusSpecSampling'
        MMDmean_ca1 = mean(AB_1vs10.MMD.ca1_HSV_noShift,3);
        MMDmean_ca2 = mean(AB_1vs10.MMD.ca2_HSV_noShift,3);
        MMDmean_mi1 = mean(AB_1vs10.MMD.mi1_Spec_Shift,3);
        MMDmean_mi1_2 = mean(AB_1vs10.MMD.mi1_Temp_Shift,3);
        MMDmean_mi2 = mean(AB_1vs10.MMD.mi2_Spec_Shift,3);
        MMDmean_mi2_2 = mean(AB_1vs10.MMD.mi2_Temp_Shift,3);        
        MMDmean_ac = mean(AB_1vs10.MMD.ac_Spec_Shift,3);
        MMDmean_ac_2 = mean(AB_1vs10.MMD.ac_Temp_Shift,3);        
        MMDmean_fr = mean(AB_1vs10.MMD.fr_Temp_Shift,3);
        MMDmean_fr_2 = mean(AB_1vs10.MMD.fr_Spec_Shift,3);        
        MMDmean_ir = mean(AB_1vs10.MMD.ir_Temp_Shift,3);
        MMDmean_ir_2 = mean(AB_1vs10.MMD.ir_Spec_Shift,3);        
        MMDmean_me = mean(AB_1vs10.MMD.me_Temp_noShift,3);
        MMDmean_me_2 = mean(AB_1vs10.MMD.me_Spec_noShift,3);
        MMDmean_me = MMDmean_me + ones(size(MMDmean_me));  % to avoid information loss with geometric means
        MMDmean_me_2 = MMDmean_me_2 + ones(size(MMDmean_me_2));  % to avoid information loss with geometric means
        DS_AB_1vs10 = zeros(size(MMDmean_me)); % discrepancy score        
        DS_AB_1vs10 = MMDmean_ca1.*MMDmean_ca2.*MMDmean_mi1.*MMDmean_mi2.*MMDmean_ac.*MMDmean_fr.*MMDmean_ir.*MMDmean_me.*...
                    MMDmean_mi1_2.*MMDmean_mi2_2.*MMDmean_ac_2.*MMDmean_fr_2.*MMDmean_ir_2.*MMDmean_me_2;
        
end

evaluateClassificationLMT108("1vs10",DS_AB_1vs10,w,kNeighbors);

%% Ablation Studies: expert vs. expert

AB_1vs1 = load('Results\LMT108_Expert_vs_Expert_AblationStudies_1080tests_n400_R10'); 

w = ones(8,1); 
kNeighbors = 1;  

% for example:
MMD_mean = mean(AB_1vs1.MMD.ac_Spec_noShift,3); 

DS_1vs1 = zeros(size(MMD_mean)); % discrepancy score
DS_1vs1 = MMD_mean;

evaluateClassificationLMT108("1vs1",DS_1vs1,w,kNeighbors);

%% Performance with individual HSV channels: image classifier

singleHSV_Result = load('Results\LMT108_traintest_2infos_Gauss_HSV_singleChannel_1080tests_n400_R10'); 

kNeighbors = 1;  
w = ones(8,1); 

% for example:
MMD_mean = mean(singleHSV_Result.MMDmatrix_ca1_hue,3); 

DS = zeros(size(MMD_mean)); % discrepancy score
DS = MMD_mean;

evaluateClassificationLMT108("1vs10",DS,w,kNeighbors);


