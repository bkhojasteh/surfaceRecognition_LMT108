%{

Description: generates results from ablation studies in 1 vs. 1 setting

Author: Behnam Khojasteh (khojasteh@is.mpg.de)
Last Modification Date: 31.01.2023

This script is part of the publication:
@article{khojasteh2023multimodal,
  title={Multimodal Multi-User Surface Recognition with the Kernel Two-Sample Test},
  author={Khojasteh, Behnam and Solowjow, Friedrich and Trimpe, Sebastian and Kuchenbecker, Katherine J},
  journal={IEEE Transactions on Automation Science and Engineering (T-ASE)},
  year={2023}
}

%}

clear all; clc;

rng('default'); % Reproducibility: Fixed indices for data extraction

rng(1);
constantStream = parallel.pool.Constant(RandStream('Threefry'));

addpath('supportScripts_LMT108')
addpath('DataLMT108/Library');

description = 'LMT108_Expert_vs_Expert_AblationStudies';

% =========== eight information sources
% ca1+ca2: camera images without and with flash
% mi1+mi2: sound from tapping and dragging
% ac: accelerations during dragging
% fr: frictional forces
% ir: infra-red surface reflectivity
% me: metal detection

%% Trial Names

trainSetting = load("DataLMT108/Library/surfaceList_LMT108train.mat");
testSetting = trainSetting;

surfaceList_Training = trainSetting.trialList_Training;
surfaceList_Testing = surfaceList_Training;

numSurfaces = 108; 

numTrials_Test = size(surfaceList_Testing,1);
numTrials_Train = size(surfaceList_Training,1) - numSurfaces;

trialsPerSurface = 10;

%% Data Selection + Testing parameters

alpha = 0.05; %
params.sig = -1; % heuristic kernel size computation
params.bootForce = 0; 
params.sigBinary = -1; % heuristic kernel size computation for metal information source

n = 400; % sample size; m = n
R = 10;  % number of repetitions of the kernel two-sample test

% %% Time Series
tempInfo.tMeasDuration_DAQ = 48E3; % in samples
t0Range_idx = 0.0115*tempInfo.tMeasDuration_DAQ;
T_drag = floor((tempInfo.tMeasDuration_DAQ-t0Range_idx)/n);

tempInfo.tMeasDuration_DAQtap = 10501; 
t0Range_idxTap = round(0.0115*tempInfo.tMeasDuration_DAQtap);
T_tap = floor((tempInfo.tMeasDuration_DAQtap-t0Range_idxTap)/n);

% %% Images
imgInfo.a = 480;
imgInfo.b = 320;
n_a = 25;
n_b = 16;
a0_range = 55; 
b0_range = 32; 

d_a = floor((imgInfo.a-a0_range)/n_a);
d_b = floor((imgInfo.b-b0_range)/n_b);

%% Frequency Ranges

% Spectral Analysis Specifications
specInfo.fRange_ac = [0 1E3];
specInfo.fRange_mi = [0 7.5E3];
specInfo.fs_ac = 10E3;
specInfo.fs_mi = 44.1E3;

trialZero = load(sprintf('DataLMT108/Library/%s',surfaceList_Testing(1)));
signal_mi1 = trialZero.soundTap_time;
signal_mi2 = trialZero.soundDrag_time;
signal_ac = trialZero.accelDrag_time(:,3);

[y_mi1, f_mi1] = powerSpectrum(signal_mi1,specInfo.fs_mi);
[y_mi2, f_mi2] = powerSpectrum(signal_mi2,specInfo.fs_mi);
[y_ac, f_ac] = powerSpectrum(signal_ac,specInfo.fs_ac);

[fMin_mi1 fMax_mi1] = getFreqIdx(f_mi1,specInfo.fRange_mi);
[fMin_mi2 fMax_mi2] = getFreqIdx(f_mi2,specInfo.fRange_mi);
[fMin_ac fMax_ac] = getFreqIdx(f_ac,specInfo.fRange_ac);

%% Similarity testing

MMDmatrix_ca1_RGB_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ca1_RGB_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ca1_HSV_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ca1_HSV_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ca2_RGB_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ca2_RGB_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ca2_HSV_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ca2_HSV_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_mi1_Temp_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_mi1_Temp_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_mi1_Spec_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_mi1_Spec_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_mi2_Temp_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_mi2_Temp_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_mi2_Spec_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_mi2_Spec_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ac_Temp_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ac_Temp_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ac_Spec_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ac_Spec_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_fr_Temp_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_fr_Temp_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_fr_Spec_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_fr_Spec_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ir_Temp_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ir_Temp_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ir_Spec_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_ir_Spec_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_me_Temp_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_me_Temp_Shift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_me_Spec_noShift = zeros(numTrials_Test,numTrials_Train,R);
MMDmatrix_me_Spec_Shift = zeros(numTrials_Test,numTrials_Train,R);

%% 1vs1 Classification Setting

trainIndicesUsers = zeros(trialsPerSurface,numSurfaces*trialsPerSurface-numSurfaces);
for i=1:trialsPerSurface
   indices = [i:trialsPerSurface:numSurfaces*trialsPerSurface];
   trainIndicesUsers(i,:) = setdiff([1:numSurfaces*trialsPerSurface],indices);    
end
idxTrain = repmat(trainIndicesUsers,numSurfaces,1);
idxTest = [1:numSurfaces*trialsPerSurface];


parfor i = 1:numTrials_Test
    i
    
    stream = constantStream.Value;        % stream from constant
    stream.Substream = i;
    
    nameZ = surfaceList_Training(idxTest(i));
    datasetZ = load(sprintf('DataLMT108/Library/%s.mat',nameZ));
    
    Z_ca1 = datasetZ.imageNoFlash_RGB;
    Z_ca1_rgb = double(Z_ca1);
    Z_ca1_hsv = rgb2hsv(Z_ca1); % RGB to HSV
    
    Z_ca2 = datasetZ.imageFlash_RGB;
    Z_ca2_rgb = double(Z_ca2);
    Z_ca2_hsv = rgb2hsv(Z_ca2); % RGB to HSV
    
    Z_mi1_temp = datasetZ.soundTap_time;
    [specAmplitudeZ_mi1, ~] = powerSpectrum(Z_mi1_temp, specInfo.fs_mi); % FFT
    Z_mi1_spec = specAmplitudeZ_mi1(fMin_mi1:fMax_mi1,1);
    
    Z_mi2_temp = datasetZ.soundDrag_time;
    [specAmplitudeZ_mi2, ~] = powerSpectrum(Z_mi2_temp, specInfo.fs_mi);  % FFT
    Z_mi2_spec = specAmplitudeZ_mi2(fMin_mi2:fMax_mi2,1);
    
    Z_ac_temp = datasetZ.accelDrag_time;
    [specAmplitudeZ_ac, ~] = powerSpectrum(Z_ac_temp, specInfo.fs_ac);     % FFT
    Z_ac_spec = specAmplitudeZ_ac(fMin_ac:fMax_ac,1:3);
    
    Z_fr_temp = datasetZ.forceDrag_time(:,1:2);
    [specAmplitudeZ_fr, ~] = powerSpectrum(Z_fr_temp, specInfo.fs_ac);     % FFT
    Z_fr_spec = specAmplitudeZ_fr(fMin_ac:fMax_ac,1:2);
    
    Z_ir_temp = datasetZ.reflectDrag_time;
    [specAmplitudeZ_ir, ~] = powerSpectrum(Z_ir_temp, specInfo.fs_ac);     % FFT
    Z_ir_spec = specAmplitudeZ_ir(fMin_ac:fMax_ac,:);
    
    Z_me_temp = datasetZ.metalDrag_time;
    [specAmplitudeZ_me, ~] = powerSpectrum(Z_me_temp, specInfo.fs_ac);     % FFT
    Z_me_spec = specAmplitudeZ_me(fMin_ac:fMax_ac,:);
    
    for j = 1:numTrials_Train       

                nameY = surfaceList_Training(idxTrain(i,j));
                datasetY = load(sprintf('DataLMT108/Library/%s.mat',nameY));

        
        Y_ca1 = datasetY.imageNoFlash_RGB;
        Y_ca1_rgb = double(Y_ca1);
        Y_ca1_hsv = rgb2hsv(Y_ca1); 
        
        Y_ca2 = datasetY.imageFlash_RGB;
        Y_ca2_rgb = double(Y_ca2);
        Y_ca2_hsv = rgb2hsv(Y_ca2); 
        
        Y_mi1_temp = datasetY.soundTap_time;
        [specAmplitudeY_mi1, ~] = powerSpectrum(Y_mi1_temp, specInfo.fs_mi); % FFT
        Y_mi1_spec = specAmplitudeY_mi1(fMin_mi1:fMax_mi1,1);
        
        Y_mi2_temp = datasetY.soundDrag_time;
        [specAmplitudeY_mi2, ~] = powerSpectrum(Y_mi2_temp, specInfo.fs_mi);  % FFT
        Y_mi2_spec = specAmplitudeY_mi2(fMin_mi2:fMax_mi2,1);
        
        Y_ac_temp = datasetY.accelDrag_time;
        [specAmplitudeY_ac, ~] = powerSpectrum(Y_ac_temp, specInfo.fs_ac);     % FFT
        Y_ac_spec = specAmplitudeY_ac(fMin_ac:fMax_ac,1:3);
        
        Y_fr_temp = datasetY.forceDrag_time(:,1:2);
        [specAmplitudeY_fr, ~] = powerSpectrum(Y_fr_temp, specInfo.fs_ac);     % FFT
        Y_fr_spec = specAmplitudeY_fr(fMin_ac:fMax_ac,1:2);
        
        Y_ir_temp = datasetY.reflectDrag_time;
        [specAmplitudeY_ir, ~] = powerSpectrum(Y_ir_temp, specInfo.fs_ac);     % FFT
        Y_ir_spec = specAmplitudeY_ir(fMin_ac:fMax_ac,:);
        
        Y_me_temp = datasetY.metalDrag_time;
        [specAmplitudeY_me, ~] = powerSpectrum(Y_me_temp, specInfo.fs_ac);     % FFT
        Y_me_spec = specAmplitudeY_me(fMin_ac:fMax_ac,:);
        
        for k = 1:R
            
            %% Equidistant sampling for images and time series
            
            a0 = randi(stream,a0_range,1);
            b0 = randi(stream,b0_range,1);
            idx_a = [a0:d_a:a0-1+d_a*n_a];
            idx_b = [b0:d_b:b0-1+d_b*n_b];
            
            z_ca1_rgb = Z_ca1_rgb(idx_a,idx_b,1:3);
            z_ca1_rgb = reshape(z_ca1_rgb,[],3);
            z_ca1_hsv = Z_ca1_hsv(idx_a,idx_b,1:3);
            z_ca1_hsv = reshape(z_ca1_hsv,[],3);
            y_ca1_rgb = Y_ca1_rgb(idx_a,idx_b,1:3);
            y_ca1_rgb = reshape(y_ca1_rgb,[],3);
            y_ca1_hsv = Y_ca1_hsv(idx_a,idx_b,1:3);
            y_ca1_hsv = reshape(y_ca1_hsv,[],3);
            
            z_ca2_rgb = Z_ca2_rgb(idx_a,idx_b,1:3);
            z_ca2_rgb = reshape(z_ca2_rgb,[],3);
            z_ca2_hsv = Z_ca2_hsv(idx_a,idx_b,1:3);
            z_ca2_hsv = reshape(z_ca2_hsv,[],3);
            y_ca2_rgb = Y_ca2_rgb(idx_a,idx_b,1:3);
            y_ca2_rgb = reshape(y_ca2_rgb,[],3);
            y_ca2_hsv = Y_ca2_hsv(idx_a,idx_b,1:3);
            y_ca2_hsv = reshape(y_ca2_hsv,[],3);
            
            t0_tap = randi(stream,t0Range_idxTap,1);
            idx_timeTap = [t0_tap:T_tap:t0_tap-1+T_tap*n];
            t0_drag = randi(stream,t0Range_idx,1);
            idx_timeDrag = [t0_drag:T_drag:t0_drag-1+T_drag*n];
            
            z_mi1_temp = Z_mi1_temp(idx_timeTap,:);
            y_mi1_temp = Y_mi1_temp(idx_timeTap,:);
            z_mi2_temp = Z_mi2_temp(idx_timeDrag,:);
            y_mi2_temp = Y_mi2_temp(idx_timeDrag,:);
            z_ac_temp = Z_ac_temp(idx_timeDrag,:);
            y_ac_temp = Y_ac_temp(idx_timeDrag,:);
            z_fr_temp = Z_fr_temp(idx_timeDrag,:);
            y_fr_temp = Y_fr_temp(idx_timeDrag,:);
            z_ir_temp = Z_ir_temp(idx_timeDrag,:);
            y_ir_temp = Y_ir_temp(idx_timeDrag,:);
            z_me_temp = Z_me_temp(idx_timeDrag,:);
            y_me_temp = Y_me_temp(idx_timeDrag,:);
                        
            %% Random sampling in spectral domain
                        
            idx_mi1 = randperm(stream,size(Z_mi1_spec,1),n);
            z_mi1_spec = Z_mi1_spec(idx_mi1,:);
            y_mi1_spec = Y_mi1_spec(idx_mi1,:);
            
            idx_mi2 = randperm(stream,size(Z_mi2_spec,1),n);
            z_mi2_spec = Z_mi2_spec(idx_mi2,:);
            y_mi2_spec = Y_mi2_spec(idx_mi2,:);
            
            idx_ac = randperm(stream,size(Z_ac_spec,1),n);
            z_ac_spec = Z_ac_spec(idx_ac,:);
            y_ac_spec = Y_ac_spec(idx_ac,:);
            z_fr_spec = Z_fr_spec(idx_ac,:);
            y_fr_spec = Y_fr_spec(idx_ac,:);
            z_ir_spec = Z_ir_spec(idx_ac,:);
            y_ir_spec = Y_ir_spec(idx_ac,:);
            z_me_spec = Z_me_spec(idx_ac,:);
            y_me_spec = Y_me_spec(idx_ac,:);
            
            %% Align mean of distributions
            
            zStar_ca1_rgb = alginMean(y_ca1_rgb,z_ca1_rgb);
            zStar_ca1_hsv = alginMean(y_ca1_hsv,z_ca1_hsv);
            zStar_ca2_rgb = alginMean(y_ca2_rgb,z_ca2_rgb);
            zStar_ca2_hsv = alginMean(y_ca2_hsv,z_ca2_hsv);
            zStar_mi1_temp = alginMean(y_mi1_temp,z_mi1_temp);
            zStar_mi1_spec = alginMean(y_mi1_spec,z_mi1_spec);
            zStar_mi2_temp = alginMean(y_mi2_temp,z_mi2_temp);
            zStar_mi2_spec = alginMean(y_mi2_spec,z_mi2_spec);
            zStar_ac_temp = alginMean(y_ac_temp,z_ac_temp);
            zStar_ac_spec = alginMean(y_ac_spec,z_ac_spec);
            zStar_fr_temp = alginMean(y_fr_temp,z_fr_temp);
            zStar_fr_spec = alginMean(y_fr_spec,z_fr_spec);
            zStar_ir_temp = alginMean(y_ir_temp,z_ir_temp);
            zStar_ir_spec = alginMean(y_ir_spec,z_ir_spec);
            zStar_me_temp = alginMean(y_me_temp,z_me_temp);
            zStar_me_spec = alginMean(y_me_spec,z_me_spec);
            
            %% Kernel Two-Sample testing
            
            [MMD_ca1_rgb_noShift,~] = mmdTestBoot(z_ca1_rgb,y_ca1_rgb,alpha, params);
            [MMD_ca1_rgb_shift,~] = mmdTestBoot(zStar_ca1_rgb,y_ca1_rgb,alpha, params);
            [MMD_ca1_hsv_noShift,~] = mmdTestBoot(z_ca1_hsv,y_ca1_hsv,alpha, params);
            [MMD_ca1_hsv_shift,~] =   mmdTestBoot(zStar_ca1_hsv,y_ca1_hsv,alpha, params);
            
            [MMD_ca2_rgb_noShift,~] = mmdTestBoot(z_ca2_rgb,y_ca2_rgb,alpha, params);
            [MMD_ca2_rgb_shift,~] = mmdTestBoot(zStar_ca2_rgb,y_ca2_rgb,alpha, params);
            [MMD_ca2_hsv_noShift,~] = mmdTestBoot(z_ca2_hsv,y_ca2_hsv,alpha, params);
            [MMD_ca2_hsv_shift,~] =   mmdTestBoot(zStar_ca2_hsv,y_ca2_hsv,alpha, params);
            
            [MMD_mi1_temp_noShift,~] = mmdTestBoot(z_mi1_temp,y_mi1_temp,alpha, params);
            [MMD_mi1_temp_shift,~] = mmdTestBoot(zStar_mi1_temp,y_mi1_temp,alpha, params);
            [MMD_mi1_spec_noShift,~] = mmdTestBoot(z_mi1_spec,y_mi1_spec,alpha, params);
            [MMD_mi1_spec_shift,~] =   mmdTestBoot(zStar_mi1_spec,y_mi1_spec,alpha, params);
            
            [MMD_mi2_temp_noShift,~] = mmdTestBoot(z_mi2_temp,y_mi2_temp,alpha, params);
            [MMD_mi2_temp_shift,~] = mmdTestBoot(zStar_mi2_temp,y_mi2_temp,alpha, params);
            [MMD_mi2_spec_noShift,~] = mmdTestBoot(z_mi2_spec,y_mi2_spec,alpha, params);
            [MMD_mi2_spec_shift,~] =   mmdTestBoot(zStar_mi2_spec,y_mi2_spec,alpha, params);
            
            [MMD_ac_temp_noShift,~] = mmdTestBoot(z_ac_temp,y_ac_temp,alpha, params);
            [MMD_ac_temp_shift,~] = mmdTestBoot(zStar_ac_temp,y_ac_temp,alpha, params);
            [MMD_ac_spec_noShift,~] = mmdTestBoot(z_ac_spec,y_ac_spec,alpha, params);
            [MMD_ac_spec_shift,~] =   mmdTestBoot(zStar_ac_spec,y_ac_spec,alpha, params);
            
            [MMD_fr_temp_noShift,~] = mmdTestBoot(z_fr_temp,y_fr_temp,alpha, params);
            [MMD_fr_temp_shift,~] = mmdTestBoot(zStar_fr_temp,y_fr_temp,alpha, params);
            [MMD_fr_spec_noShift,~] = mmdTestBoot(z_fr_spec,y_fr_spec,alpha, params);
            [MMD_fr_spec_shift,~] =   mmdTestBoot(zStar_fr_spec,y_fr_spec,alpha, params);
            
            [MMD_ir_temp_noShift,~] = mmdTestBoot(z_ir_temp,y_ir_temp,alpha, params);
            [MMD_ir_temp_shift,~] = mmdTestBoot(zStar_ir_temp,y_ir_temp,alpha, params);
            [MMD_ir_spec_noShift,~] = mmdTestBoot(z_ir_spec,y_ir_spec,alpha, params);
            [MMD_ir_spec_shift,~] =   mmdTestBoot(zStar_ir_spec,y_ir_spec,alpha, params);
            
            [MMD_me_temp_noShift,~] = mmdTestBoot_metal(z_me_temp,y_me_temp,alpha, params);
            [MMD_me_temp_shift,~] = mmdTestBoot_metal(zStar_me_temp,y_me_temp,alpha, params);
            [MMD_me_spec_noShift,~] = mmdTestBoot_metal(z_me_spec,y_me_spec,alpha, params);
            [MMD_me_spec_shift,~] =   mmdTestBoot_metal(zStar_me_spec,y_me_spec,alpha, params);
                        
            MMDmatrix_ca1_RGB_noShift(i,j,k) = MMD_ca1_rgb_noShift;
            MMDmatrix_ca1_RGB_Shift(i,j,k) = MMD_ca1_rgb_shift;
            MMDmatrix_ca1_HSV_noShift(i,j,k) = MMD_ca1_hsv_noShift;
            MMDmatrix_ca1_HSV_Shift(i,j,k) = MMD_ca1_hsv_shift;
            MMDmatrix_ca2_RGB_noShift(i,j,k) = MMD_ca2_rgb_noShift;
            MMDmatrix_ca2_RGB_Shift(i,j,k) = MMD_ca2_rgb_shift;
            MMDmatrix_ca2_HSV_noShift(i,j,k) = MMD_ca2_hsv_noShift;
            MMDmatrix_ca2_HSV_Shift(i,j,k) = MMD_ca2_hsv_shift;
            MMDmatrix_mi1_Temp_noShift(i,j,k) = MMD_mi1_temp_noShift;
            MMDmatrix_mi1_Temp_Shift(i,j,k) = MMD_mi1_temp_shift;
            MMDmatrix_mi1_Spec_noShift(i,j,k) = MMD_mi1_spec_noShift;
            MMDmatrix_mi1_Spec_Shift(i,j,k) = MMD_mi1_spec_shift;
            MMDmatrix_mi2_Temp_noShift(i,j,k) = MMD_mi2_temp_noShift;
            MMDmatrix_mi2_Temp_Shift(i,j,k) = MMD_mi2_temp_shift;
            MMDmatrix_mi2_Spec_noShift(i,j,k) = MMD_mi2_spec_noShift;
            MMDmatrix_mi2_Spec_Shift(i,j,k) = MMD_mi2_spec_shift;
            MMDmatrix_ac_Temp_noShift(i,j,k) = MMD_ac_temp_noShift;
            MMDmatrix_ac_Temp_Shift(i,j,k) = MMD_ac_temp_shift;
            MMDmatrix_ac_Spec_noShift(i,j,k) = MMD_ac_spec_noShift;
            MMDmatrix_ac_Spec_Shift(i,j,k) = MMD_ac_spec_shift;
            MMDmatrix_fr_Temp_noShift(i,j,k) = MMD_fr_temp_noShift;
            MMDmatrix_fr_Temp_Shift(i,j,k) = MMD_fr_temp_shift;
            MMDmatrix_fr_Spec_noShift(i,j,k) = MMD_fr_spec_noShift;
            MMDmatrix_fr_Spec_Shift(i,j,k) = MMD_fr_spec_shift;
            MMDmatrix_ir_Temp_noShift(i,j,k) = MMD_ir_temp_noShift;
            MMDmatrix_ir_Temp_Shift(i,j,k) = MMD_ir_temp_shift;
            MMDmatrix_ir_Spec_noShift(i,j,k) = MMD_ir_spec_noShift;
            MMDmatrix_ir_Spec_Shift(i,j,k) = MMD_ir_spec_shift;
            MMDmatrix_me_Temp_noShift(i,j,k) = MMD_me_temp_noShift;
            MMDmatrix_me_Temp_Shift(i,j,k) = MMD_me_temp_shift;
            MMDmatrix_me_Spec_noShift(i,j,k) = MMD_me_spec_noShift;
            MMDmatrix_me_Spec_Shift(i,j,k) = MMD_me_spec_shift;            
            
        end
    end
end

%% For export

imgInfo.a0_range = a0_range; 
imgInfo.b0_range = b0_range; 
imgInfo.n_a = n_a;
imgInfo.n_b = n_b;

trainSetting.idxTrain = idxTrain;
testSetting.idxTest = idxTest;

MMD.ca1_RGB_noShift = MMDmatrix_ca1_RGB_noShift;
MMD.ca1_RGB_Shift = MMDmatrix_ca1_RGB_Shift;
MMD.ca1_HSV_noShift = MMDmatrix_ca1_HSV_noShift;
MMD.ca1_HSV_Shift = MMDmatrix_ca1_HSV_Shift;
MMD.ca2_RGB_noShift = MMDmatrix_ca2_RGB_noShift;
MMD.ca2_RGB_Shift = MMDmatrix_ca2_RGB_Shift;
MMD.ca2_HSV_noShift = MMDmatrix_ca2_HSV_noShift;
MMD.ca2_HSV_Shift = MMDmatrix_ca2_HSV_Shift;
MMD.mi1_Temp_noShift = MMDmatrix_mi1_Temp_noShift;
MMD.mi1_Temp_Shift = MMDmatrix_mi1_Temp_Shift;
MMD.mi1_Spec_noShift = MMDmatrix_mi1_Spec_noShift;
MMD.mi1_Spec_Shift = MMDmatrix_mi1_Spec_Shift;
MMD.mi2_Temp_noShift = MMDmatrix_mi2_Temp_noShift;
MMD.mi2_Temp_Shift = MMDmatrix_mi2_Temp_Shift;
MMD.mi2_Spec_noShift = MMDmatrix_mi2_Spec_noShift;
MMD.mi2_Spec_Shift = MMDmatrix_mi2_Spec_Shift;
MMD.ac_Temp_noShift = MMDmatrix_ac_Temp_noShift;
MMD.ac_Temp_Shift = MMDmatrix_ac_Temp_Shift;
MMD.ac_Spec_noShift = MMDmatrix_ac_Spec_noShift;
MMD.ac_Spec_Shift = MMDmatrix_ac_Spec_Shift;
MMD.fr_Temp_noShift = MMDmatrix_fr_Temp_noShift;
MMD.fr_Temp_Shift = MMDmatrix_fr_Temp_Shift;
MMD.fr_Spec_noShift = MMDmatrix_fr_Spec_noShift;
MMD.fr_Spec_Shift = MMDmatrix_fr_Spec_Shift;
MMD.ir_Temp_noShift = MMDmatrix_ir_Temp_noShift;
MMD.ir_Temp_Shift = MMDmatrix_ir_Temp_Shift;
MMD.ir_Spec_noShift = MMDmatrix_ir_Spec_noShift;
MMD.ir_Spec_Shift = MMDmatrix_ir_Spec_Shift;
MMD.me_Temp_noShift = MMDmatrix_me_Temp_noShift;
MMD.me_Temp_Shift = MMDmatrix_me_Temp_Shift;
MMD.me_Spec_noShift = MMDmatrix_me_Spec_noShift;
MMD.me_Spec_Shift = MMDmatrix_me_Spec_Shift;


dataname = sprintf('Results/%s_%dtests_n%d_R%d',description,numTrials_Test,n,R);
save(dataname,'numTrials_Test','numTrials_Train','testSetting','trainSetting','R','n','imgInfo','tempInfo','specInfo','MMD','-v7.3');

