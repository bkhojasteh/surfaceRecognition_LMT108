%{

Description: kNN classifier with similarity scores for an unlabeled trial

Author: Behnam Khojasteh (khojasteh@is.mpg.de)
Last Modification Date: 31.01.2023

This script is part of the publication:
@article{khojasteh2023multimodal,
  title={Multimodal Multi-User Surface Recognition with the Kernel Two-Sample Test},
  author={Khojasteh, Behnam and Solowjow, Friedrich and Trimpe, Sebastian and Kuchenbecker, Katherine J},
  journal={IEEE Transactions on Automation Science and Engineering (T-ASE)},
  year={2023}
}

%}

function [predictedLabel__weightedKNN,predictedTrial__weightedKNN] = ...
    kNNClassifier(testTrial,labelSets,numLabels,numberKNN)
% Outputs NN for a test trial

[DSascending,permutIDX] = sort(testTrial,'ascend');

DSvaluesKNN = DSascending(1:numberKNN);
kNNeighbors = permutIDX(1:numberKNN);

kNNLabels = zeros(size(kNNeighbors));
for j=1:size(kNNeighbors,2)
    [~ ,column]= find(labelSets==kNNeighbors(j));
    kNNLabels(1,j) = column;
end

    KNNweights = 1./DSvaluesKNN; % Inverse weighting function    
    
    cumulatedWeights = zeros(numLabels,1);
    for labelID=1:numLabels
        [~,columnWeighted] = find(kNNLabels == labelID);
        if(~isempty(columnWeighted))
            cumulatedWeights(labelID,1) = sum(KNNweights(columnWeighted));
        end
    end
    [~,labelBestKNNweighted] = max(cumulatedWeights);
    predictedLabel__weightedKNN = labelBestKNNweighted;
    [~, trialHelperBestKNNweighted] = find(kNNLabels == labelBestKNNweighted);
    predictedTrial__weightedKNN = {kNNeighbors(trialHelperBestKNNweighted)};

end