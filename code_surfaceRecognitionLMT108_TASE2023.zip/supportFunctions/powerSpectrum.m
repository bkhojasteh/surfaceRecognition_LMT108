function [specAmplitude, f] = powerSpectrum( signal, Fs)
%% Compute FFT from input signal

L = size(signal,1); % Number of samples
NFFT = 2^nextpow2(L);
amp_fft = fft(signal, NFFT)/L;
f = Fs/2*linspace(0, 1, NFFT/2+1);
specAmplitude = 2*abs(amp_fft(1:NFFT/2+1,:)); % Power spectrum; half non-redundant part

end

