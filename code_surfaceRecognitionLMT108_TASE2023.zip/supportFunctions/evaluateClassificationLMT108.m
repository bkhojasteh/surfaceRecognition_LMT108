%{

Description: complements evaluation script for classification performance

Author: Behnam Khojasteh (khojasteh@is.mpg.de)
Last Modification Date: 31.01.2023

This script is part of the publication:
@article{khojasteh2023multimodal,
  title={Multimodal Multi-User Surface Recognition with the Kernel Two-Sample Test},
  author={Khojasteh, Behnam and Solowjow, Friedrich and Trimpe, Sebastian and Kuchenbecker, Katherine J},
  journal={IEEE Transactions on Automation Science and Engineering (T-ASE)},
  year={2023}
}

%}

function evaluateClassificationLMT108(classificationSetting,DS,w,kNeighbors)



%% Evaluate classification performance of users

numLabels = 108;
numTestTrialsPerLabel = 10; % from 10 users

switch classificationSetting
    case "1vs10"
        labelArray = reshape([1:numTestTrialsPerLabel*numLabels],[numTestTrialsPerLabel,numLabels]); 
        libraryTrials = [1:numTestTrialsPerLabel*numLabels];   
    case "1vs1"
        labelArray = reshape([1:(numTestTrialsPerLabel-1)*numLabels],[numTestTrialsPerLabel-1,numLabels]); 
        libraryTrials = [1:(numTestTrialsPerLabel-1)*numLabels];   
    case "10vs1"
        labelArray = reshape([1:(2*numTestTrialsPerLabel-1)*numLabels],[(2*numTestTrialsPerLabel-1),numLabels]);
        libraryTrials = [1:(2*numTestTrialsPerLabel-1)*numLabels];  
end
kNNclassifierWeighted = NaN(numTestTrialsPerLabel,numLabels,kNeighbors);
predLabel_mKNN = zeros(numTestTrialsPerLabel,numLabels,kNeighbors);
predLabel_wKNN = zeros(numTestTrialsPerLabel,numLabels,kNeighbors);

for user = 1:numTestTrialsPerLabel
    
    testTrialUser = [user:numTestTrialsPerLabel:numTestTrialsPerLabel*numLabels];
    MMDmatrixOneUser = DS(testTrialUser,libraryTrials);
    
    for kvalue=1:kNeighbors
        for i=1:size(MMDmatrixOneUser,1)
            
            testingInstance = MMDmatrixOneUser(i,:);
            
            [predLabel_weightedKNN,predTrial_weightedKNN] = ...
                kNNClassifier(testingInstance,labelArray,numLabels,kvalue); % kNN for 1 unlabeled trial
            
            predLabel_wKNN(user,i,kvalue)  = predLabel_weightedKNN;
            predTrial_wKNN(user,i,kvalue) = predTrial_weightedKNN;
            if(predLabel_wKNN(user,i,kvalue) == i)
                kNNclassifierWeighted(user,i,kvalue) = 0; % correct classification
            else
                kNNclassifierWeighted(user,i,kvalue) = 1; % misclassification
            end

        end
    end
end

%% CLASSIFICATION PERFORMANCE METRICS

% Confusion Matrix for kNN
targets = repelem([1:numLabels],numTestTrialsPerLabel)';
confusionMatrix_wkNN = zeros(numLabels,numLabels);
for k=1:kNeighbors
    predictedOutputs_wkNN = reshape(predLabel_wKNN(:,:,k),[],1);
    confusionMatrix_wkNN(:,:,k) = confusionmat(targets,predictedOutputs_wkNN);
end

% Classification Accuracy and Precision
numTestInstances = numLabels*numTestTrialsPerLabel; % = size(DS,1)

classAccuracy_wkNN = zeros(numTestTrialsPerLabel,kvalue);
classPrecision_wkNN = zeros(numLabels,kvalue);
for kvalue = 1:kNeighbors
    for j = 1:numTestTrialsPerLabel
        classAccuracy_wkNN(j,kvalue) = (numLabels-sum(sum(kNNclassifierWeighted(j,:,kvalue))))/numLabels*100;
    end
    
    for l = 1:numLabels
        classPrecision_wkNN(l,kvalue) = confusionMatrix_wkNN(l,l,kvalue)/sum(confusionMatrix_wkNN(:,l,kvalue))*100;
    end
end
classPrecision_wkNN(isnan(classPrecision_wkNN))=0;

% Performance for 1-NN classifier
meanAccuracy = mean(classAccuracy_wkNN(:,1));
stdAccuracy = std(classAccuracy_wkNN(:,1));
meanPrecision = mean(classPrecision_wkNN(:,1));
C_1NN = confusionMatrix_wkNN(:,:,1);

% Performance Info String
display(sprintf('Accuracy = %0.1f +- %0.1f, Mean Precision = %2.f',meanAccuracy,stdAccuracy,meanPrecision));


% %%
% % Confusion matrix for 1-NN classifier
% figure;
% % A=image(C_1NN);
% A=imagesc(C_1NN);
% colormap(flipud(gray(1E5))); axis equal; axis tight;
% xticks([13.5 22.5 31.5 44.5 49.5 64.5 76.5 91.5]);
% yticks([13.5 22.5 31.5 44.5 49.5 64.5 76.5 91.5]);
% set(gca,'Yticklabel',[])
% set(gca,'Xticklabel',[]) 
% ylabel('True Class')
% xlabel('Prediction')




end

