function Zstar = alginMean(Y,Z)
% Align the mean of the distributions Y and Z

muY = mean(Y);
muZ = mean(Z);
Zstar = Z - muZ.*ones(size(Z)) + muY.*ones(size(Y));

end