function [fMin fMax] = getFreqIdx(f_array,f_range)
%% Extract indices of frequency range

minF = find( f_array >= f_range(1));
maxF = find( f_array <= f_range(2));
freRange_vector = intersect(minF,maxF);
fMin = freRange_vector(1);
fMax = freRange_vector(end);

end