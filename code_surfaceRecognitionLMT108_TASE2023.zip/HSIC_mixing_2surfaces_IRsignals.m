%{

Description: generates results for figure 7

Author: Behnam Khojasteh (khojasteh@is.mpg.de)
Last Modification Date: 31.01.2023

This script is part of the publication:
@article{khojasteh2023multimodal,
  title={Multimodal Multi-User Surface Recognition with the Kernel Two-Sample Test},
  author={Khojasteh, Behnam and Solowjow, Friedrich and Trimpe, Sebastian and Kuchenbecker, Katherine J},
  journal={IEEE Transactions on Automation Science and Engineering (T-ASE)},
  year={2023}
}

%}

clc; clear all;

% addpath('H:\Project_ToolSurface\Scripts\2sampleTest\LMTdata\108TexturesTraining_Reflectance');
addpath('DataLMT108/Library');
addpath('supportFunctions')
addpath('Results');

% check if computations would run locally
load('surfaceList_LMT108train');
surfaceList = trialList_Training; % expert trials

% Reproducibility: Fixed indices for data extraction
rng('default');
rng(1);
constantStream = parallel.pool.Constant(RandStream('Threefry'));

description = 'HSIC_IRsignal_2surfaces_LMT108';

doCalculation = false;

%% Parameters for HSIC and Experiment

% %HSIC Parameters
alpha = 0.05;
params.sigx = -1;
params.sigy = -1;
params.shuff = 100;
params.bootForce = 0;

%% Testing parameters

R = 500;
Q = 10;
numChannels = 2;
numSurfaces = 2;

t1_max = 20000; % 1 second
% T_total = 4.8E3;
maxSearchRangeForT = 1000; % 100ms; alternative implementaion with while do

dataname = sprintf('Results/%s_Q%d_R%d_t1max%d',description,Q,R,t1_max);

surfaceID = [111 661]; % surface ID for aluminum mesh and EPDM foam

if(doCalculation)
          
    HSICarray = zeros(R,maxSearchRangeForT,numSurfaces);
    kappaArray = zeros(R,maxSearchRangeForT,numSurfaces);
    confidenceBounds = zeros(maxSearchRangeForT,2,numSurfaces);
    TstarArray = zeros(numSurfaces,1);
    
    for i = 1:numSurfaces
        
        Y1 = load(surfaceList(surfaceID(i)));
        Y2 = load(surfaceList(surfaceID(i)+1));
        Y3 = load(surfaceList(surfaceID(i)+2));
        Y4 = load(surfaceList(surfaceID(i)+3));
        Y5 = load(surfaceList(surfaceID(i)+4));
        Y6 = load(surfaceList(surfaceID(i)+5));
        Y7 = load(surfaceList(surfaceID(i)+6));
        Y8 = load(surfaceList(surfaceID(i)+7));
        Y9 = load(surfaceList(surfaceID(i)+8));
        Y10 = load(surfaceList(surfaceID(i)+9));
        
        data = cell(Q,1);
        data{1} = Y1.reflectDrag_time'; data{2} = Y2.reflectDrag_time'; data{3} = Y3.reflectDrag_time'; data{4} = Y4.reflectDrag_time'; data{5} = Y5.reflectDrag_time';
        data{6} = Y6.reflectDrag_time'; data{7} = Y7.reflectDrag_time'; data{8} = Y8.reflectDrag_time'; data{9} = Y9.reflectDrag_time'; data{10} = Y10.reflectDrag_time';
        
        for t=1:maxSearchRangeForT
            t
            parfor r=1:R
                t1 = randi([1 t1_max],1);
                Y = zeros(numChannels, Q);
                Z = zeros(numChannels, Q);
                for j = 1:Q
                    Y(:,j) = data{j}(:,t1);
                    Z(:,j) = data{j}(:,t1 + t);
                end
                [kappa,HSIC] = hsicTestBoot(Y',Z',alpha,params);
                HSICarray(r,t,i) = HSIC;
                kappaArray(r,t,i) = kappa;
            end                        
            SEM = std(HSICarray(:,t,i))/sqrt(length(HSICarray(:,t,i)));               % Standard Error
            ts = tinv([alpha/2 1-alpha/2],length(HSICarray(:,t,i))-1);      % T-Score
            confidenceBounds(t,:,i) = mean(HSICarray(:,t,i)) + ts*SEM; % mean(x) ~ meanTestStatistics(i,texture)
        end    
        [tStarhelper ~]= find(confidenceBounds(:,2,i) <  mean(kappaArray(:,:,i),1));
        TstarArray(i,1) = tStarhelper(1);
    end
   
    %% Saving data

       save(dataname,'confidenceBounds','kappaArray','TstarArray','R','Q','t1_max','-v7.3');  
       
else
    load(sprintf('%s.mat',dataname));    
end

%% Plotting

% inputvector = [1 2];

greyColor = [170 166 164]./255;
magentaColor = [231 96 191]./255;
lineWidth = 2;

fs = 10E3;
timeArray = [0:1/fs:maxSearchRangeForT/fs-1/fs];
TstarArraySeconds = TstarArray./fs;

figure;
for k = 1:numSurfaces
    
    CBminus = confidenceBounds(:,1,k);
    CBplus = confidenceBounds(:,2,k);
    testStatisticMean = mean(confidenceBounds(:,:,k),2);
    kappaMean = mean(kappaArray(:,:,k),1);

    subplot(2,1,k)
    plot(timeArray,kappaMean,'-','Color',magentaColor,'LineWidth',lineWidth); hold on;
    plot(timeArray,CBminus,'Color',greyColor,'LineWidth',lineWidth);
    plot(timeArray,CBplus,'Color',greyColor,'LineWidth',lineWidth);
    plot(timeArray,testStatisticMean,'k-','LineWidth',lineWidth); hold on;
    xline(TstarArraySeconds(k,1),'k:','LineWidth',lineWidth)
    xlabel('Time (s)')
    ylabel('HSIC')
    xlim([0 0.1]);
    ylim([0 0.12]);
    yticks([0:0.12:0.12]);
    xticks([0:0.05:0.1]);
end






